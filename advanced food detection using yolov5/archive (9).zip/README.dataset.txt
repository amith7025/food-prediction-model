# food detector > 2023-03-21 12:24pm
https://universe.roboflow.com/intel-n2yjd/food-detector-acbog

Provided by a Roboflow user
License: CC BY 4.0

